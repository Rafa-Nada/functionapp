import azure.functions as func
import logging
import os
import requests
import json

# Read settings from environment variables
WEBHOOK_URL = os.environ.get("WEBHOOK_URL")
AUTH_TOKEN = os.environ.get("WEBHOOK_AUTH_TOKEN")

app = func.FunctionApp()

@app.function_name(name="ForwardToWebhook")
@app.event_hub_message_trigger(
    arg_name="event",
    event_hub_name="evolveops",  # Your actual Event Hub name
    connection="EventHubConnection"  # Must be set in Azure App Settings
)
def forward_to_webhook(event: func.EventHubEvent):
    try:
        body = event.get_body().decode("utf-8")
        logging.info(f"Received Event Hub message: {body}")

        if not WEBHOOK_URL or not AUTH_TOKEN:
            logging.error("Missing WEBHOOK_URL or WEBHOOK_AUTH_TOKEN environment variable.")
            return

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {AUTH_TOKEN}"
        }

        # Optional: validate or pretty-print JSON
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            logging.warning("Received non-JSON payload. Sending as raw string.")
            payload = body

        response = requests.post(
            WEBHOOK_URL,
            headers=headers,
            json=payload if isinstance(payload, dict) else None,
            data=None if isinstance(payload, dict) else body
        )
        response.raise_for_status()
        logging.info("Successfully forwarded to webhook.")

    except Exception as e:
        logging.error(f"Failed to forward to webhook: {e}")
